<?php
//Importou a classe usuário da controller
use Controller\UsuarioController;
//Autoload e cabeçalho
require_once 'vendor/autoload.php';
require_once './shared/header.php';

?>

<!-- HTML AQUI -->
<div class="table-responsive">
    <table
        class="table table-primary">
        <thead>
            <tr>
                <th scope="col">Id</th>
                <th scope="col">Nome</th>
                <th scope="col">Email</th>
                <th scope="col">Operações</th>
            </tr>
        </thead>
        <tbody>
            <?php
            //Instancia o objeto usuarios da controller
            $usuarios = new UsuarioController;

            //$result é o array que carrega a lista de usuários
            $result = $usuarios->loadAll();
            foreach ($result as $key => $value) {
                echo '<tr class="">';
                    echo ' <td>'.$value['id'].'</td>';
                    echo ' <td>'.$value['nome'].'</td>';
                    echo ' <td>'.$value['email'].'</td>';
                    echo ' <td>
                                <a href="manterUsuarios.php?id='.$value['id'].'&&cod=editar" class="btn btn-warning">Editar</a>
                                <a href="manterUsuarios.php?id='.$value['id'].'&&cod=excluir" class="btn btn-danger">Excluir</a>
                                </td>';
                echo ' </tr>';
            }
            ?>
        </tbody>
    </table>
</div>






<?php
require_once './shared/footer.php';
?>