<?php

namespace Controller;

use Model\projetosModel;

require './vendor/autoload.php';

class projetosController
{

    //Método construtor.
    public function __construct() {}

/*
    public function loadById($id)
    {
        $proj = new projetosModel;
        $proj = $proj->loadById($id); //loadbyId está na model agora e retorna um objeto do tipo usuário
        return $proj;
    }*/

    public function loadAll()
    {
        $proj = new projetosModel;
        $result = $proj->loadAll(); //$result é uma array que retorna do banco de dados.
        return $result;
    }

    public function delete()
    {   
        @$id = $_REQUEST['id'];
        $proj = new projetosModel;
        $proj->delete($id);
        if($proj->total > 0){
            header('location: \listarProjetos.php?cod=success');
        }else{
            header('location: \listarProjetos.php?cod=error');
        }
    }

    
    public function save()
    {
        if ($_POST) {
            @$proj = new projetosModel;
            @$proj->setId($_POST['id']);
            @$proj->setNome($_POST['nomeProjeto']);
            @$proj->setDescricaoProjeto($_POST['descricaoProjeto']);
            @$proj->setDataFim($_POST['dataFim']);
            @$proj->setDataInicio($_POST['dataInicio']); 
            @$proj->setStatusProjeto($_POST['statusProjeto']);
            @$proj->save();
            if($proj->total> 0){
                //success
                //Não precisa mais colocar ../ somente colocar \ que redireciona para a raiz.
                header('location: \listarProjetos.php?cod=success');
            }else{
                //error
                header('location: \manterProjeto.php?cod=error');
            }
        }
    }
    
}
