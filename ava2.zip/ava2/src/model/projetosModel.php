<?php

namespace Model;

require './vendor/autoload.php';

use Controller\projetosController;

class projetosModel
{


    protected $id;
    protected $nome;
    protected $descricaoProjeto;
    protected $statusProjeto;
    protected $dataInicio;
    protected $dataFim;

    public    $total;


    public function __construct() {}

    
    /**
     * Get the value of id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId($id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of nome
     */
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     */
    public function setNome($nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of descricaoProjeto
     */
    public function getDescricaoProjeto()
    {
        return $this->descricaoProjeto;
    }

    /**
     * Set the value of descricaoProjeto
     */
    public function setDescricaoProjeto($descricaoProjeto): self
    {
        $this->descricaoProjeto = $descricaoProjeto;

        return $this;
    }

    /**
     * Get the value of statusProjeto
     */
    public function getStatusProjeto()
    {
        return $this->statusProjeto;
    }

    /**
     * Set the value of statusProjeto
     */
    public function setStatusProjeto($statusProjeto): self
    {
        $this->statusProjeto = $statusProjeto;

        return $this;
    }

    /**
     * Get the value of dataInicio
     */
    public function getDataInicio()
    {
        return $this->dataInicio;
    }

    /**
     * Set the value of dataInicio
     */
    public function setDataInicio($dataInicio): self
    {
        $this->dataInicio = $dataInicio;

        return $this;
    }

    /**
     * Get the value of dataFim
     */
    public function getDataFim()
    {
        return $this->dataFim;
    }

    /**
     * Set the value of dataFim
     */
    public function setDataFim($dataFim): self
    {
        $this->dataFim = $dataFim;

        return $this;
    }

    /**
     * Get the value of total
     */
    public function getTotal()
    {
        return $this->total;
    }

    /**
     * Set the value of total
     */
    public function setTotal($total): self
    {
        $this->total = $total;

        return $this;
    }
    



    /*public function loadById($id)
    {

        $db = new ConexaoMysql;
        $db->conectar();

        $sql = 'SELECT * FROM usuarios WHERE id=' . $id;

        $resultList = $db->consultar($sql);

        if ($db->total > 0) {
            foreach ($resultList as $key => $value) {
                $this->id = $value['id'];
                $this->nome = $value['nome'];
                $this->email = $value['email'];
                $this->senha = $value['senha'];
            }
        }
        $db->desconectar();

        //Retorna o total de registros que vem da consulta $sql no banco de dados.
        $this->total = $db->total;

        return $this;
    }
*/
    public function loadAll()
    {

        $db = new ConexaoMysql;
        $db->conectar();

        $sql = 'SELECT * FROM projetos';

        $resultList = $db->consultar($sql);

        $db->desconectar();

        //Retorna o total de registros que vem da consulta $sql no banco de dados.
        $this->total = $db->total;

        return $resultList;
    }



    public function save()
    {

        $db = new ConexaoMysql;
        $db->conectar();

        if (empty($this->getId())) {
            //Inserir
            $sql = 'INSERT INTO projetos VALUES(0,"'.$this->nome.'","'.$this->descricaoProjeto.'","'.$this->dataInicio.'","'.$this->dataFim.'",1,"'.$this->statusProjeto.'")';
        } else {            //Atualizar
            $sql = 'UPDATE projetos SET nome="'.$this->nome.'",
             descricao="'.$this->descricaoProjeto.'", data_inicio="'.$this->dataInicio.'", data_fim="'.$this->dataFim.'", status_id="'.$this->statusProjeto.'" WHERE id='.$this->id.';';
        }

        $db->executar($sql);
        $db->desconectar();
        //Retorna o total de registros que vem da consulta $sql no banco de dados.
        $this->total = $db->total;
        return $this->total;
    }


    public function delete($id)
    {

        $db = new ConexaoMysql;
        $db->conectar();

        $sql = 'DELETE FROM usuarios WHERE id=' . $id;

        $db->executar($sql);

       $db->desconectar();

        //Retorna o total de registros que vem da consulta $sql no banco de dados.
        $this->total = $db->total;

        return $this->total;
    }


}
