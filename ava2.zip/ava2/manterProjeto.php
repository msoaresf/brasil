<?php

use Controller\projetosController;

require_once './vendor/autoload.php';

$proj = new projetosController;

require_once './shared/header.php';
?>

<div class="container my-4">
        <h1 class="mb-4">Cadastro de Novo Projeto</h1>
        <form  method="POST" action="<?php $proj->save(); ?>">
            <div class="mb-3">
                <label for="nomeProjeto" class="form-label">Nome do Projeto</label>
                <input type="text" class="form-control" id="nomeProjeto" name="nomeProjeto" required>
            </div>
            <div class="mb-3">
                <label for="descricaoProjeto" class="form-label">Descrição</label>
                <textarea class="form-control" id="descricaoProjeto" name="descricaoProjeto" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="statusProjeto" class="form-label">Status</label>
                <select class="form-select" id="statusProjeto" name="statusProjeto" required>
                    <!-- TODO: Adicione os status dinamicamente - Contempla funcionalidade de cadastrar e editar projeto (Não apagar TODO.) -->
                    <option value="1" selected>Em Andamento</option>
                    <option value="2">Concluído</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="dataInicio" class="form-label">Data de Início</label>
                <input type="date" class="form-control" id="dataInicio" name="dataInicio" required>
            </div>
            <div class="mb-3">
                <label for="dataFim" class="form-label">Data de Término</label>
                <input type="date" class="form-control" id="dataFim" name="dataFim" required>
            </div>
            <input type="submit" class="btn btn-primary" value="Salvar">
            <a href="listarProjetos.php" class="btn btn-secondary">Cancelar</a>
        </form>
        <?php 
  @$cod = $_REQUEST['cod'];
  if(isset($cod)){ 
        if($cod == 'error'){
            echo ('<br><div class="alert alert-error">');
            echo ('Projeto nao cadastrado');
            echo ('</div>');
          }
      
        }
      
      ?>
    </div>

<?php
require_once './shared/footer.php';
?>