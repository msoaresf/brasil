<?php

use Controller\projetosController;

require_once './vendor/autoload.php';

$proj = new projetosController;

require_once './shared/header.php';
?>
        <div class="container my-4">
            <h1 class="mb-4">Projetos</h1>
            <div class="d-flex justify-content-between mb-4">
                <h4>Lista de Projetos</h4>
                <!-- TODO: Implementar a funcionalidade de cadastrar novo projeto - 1 PONTO (Não apagar TODO.) -->
                <a href="manterProjeto.php" class="btn btn-primary">Novo Projeto</a>
            </div>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Nome do Projeto</th>
                            <th>Descrição</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
            //Instancia o objeto usuarios da controller
            $proj = new projetosController;

            //$result é o array que carrega a lista de usuários
            $result = $proj->loadAll();
            foreach ($result as $key => $value) {
                echo '<tr>';
                    echo ' <td>'.$value['nome'].'</td>';
                    echo ' <td>'.$value['descricao'].'</td>';
                    echo ' <td>
                                <a href="manterProjeto.php?id='.$value['id'].'&&cod=editar" class="btn btn-warning">Editar</a>
                                <a href="listarProjetos.php?id='.$value['id'].'&&cod=excluir" class="btn btn-danger">Excluir</a>
                                </td>';
                echo ' </tr>';
            }
            ?>
                    <tr>
                            <td>Projeto Exemplo 1</td>
                            <td>Descrição do projeto 1</td>
                            <td>
                                <!-- TODO: Implementar a funcionalidade de editar projeto - 1 PONTO. (Não apagar TODO.) -->
                                <button class="btn btn-sm btn-warning">Editar</button>
                                <!-- TODO: Implementar a funcionalidade de excluir projeto - 1 PONTO (Não apagar TODO.) -->
                                <button class="btn btn-sm btn-danger">Excluir</button>
                            </td>
                        </tr>
                        <!-- TODO: Fazer dinâmico para carregar outros projetos  - 1 PONTO (Não apagar TODO.) -->
                    </tbody>
                </table>
                <?php 
                   
   @$cod = $_REQUEST['cod'];
   if(isset($cod)){ 
           if ($cod == 'success') {
               echo ('<br><div class="alert alert-success">');
               echo ('Projeto cadastrado.');
               echo ('</div>');
           }
       }
                ?>
            </div>
        </div>
<?php

require_once './shared/footer.php';
?>