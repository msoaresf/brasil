<?php
require_once './shared/header.php';
?>

<div class="container my-4">
    <h1 class="mb-4">Cadastro de Nova Tarefa</h1>
    <form action="tarefasController.php" method="POST">
        <div class="mb-3">
            <label for="nomeTarefa" class="form-label">Nome da Tarefa</label>
            <input type="text" class="form-control" id="nomeTarefa" name="nome" required>
        </div>
        <div class="mb-3">
            <label for="descricaoTarefa" class="form-label">Descrição</label>
            <textarea class="form-control" id="descricaoTarefa" name="descricao" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label for="projetoTarefa" class="form-label">Projeto</label>
            <select class="form-select" id="projetoTarefa" name="projeto_id" required>
                <option value="" selected>Escolha um projeto...</option>
                 <!-- TODO: Adicione os projetos dinamicamente  - Contempla funcionalidade extra de cadastrar e editar tarefa (Não apagar TODO.) -->
                <option value="1">Projeto 1</option>
                <option value="2">Projeto 2</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="statusTarefa" class="form-label">Status</label>
            <select class="form-select" id="statusTarefa" name="status" required>
                 <!-- TODO: Adicione os status dinamicamente - Contempla funcionalidade extra de cadastrar e editar tarefa (Não apagar TODO.) -->
                <option value="1" selected>Pendente</option>
                <option value="2">Em Andamento</option>
                <option value="3">Concluído</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="prazoTarefa" class="form-label">Prazo</label>
            <input type="date" class="form-control" id="prazoTarefa" name="prazo" required>
        </div>
        <input type="submit" class="btn btn-primary" value="Salvar">
        <a href="listarTarefas.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php
require_once './shared/footer.php';
?>