<!DOCTYPE html>
<html lang="en">
<head>
  
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
    .row.content {height: 1500px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
      display: block;
      
    }
  
    /* Set black background color, white text and some padding */
    
   
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-2 sidenav">
      <h4>SHIUUMA</h4>
      <ul class="nav nav-pills nav-stacked">
        <li class="active"><a href="index.php">Pagina principal</a></li>
        <li><a href="adm.php">Pagina do administrador</a></li>
        <li><a href="cadastrarProduto.php">Cadastrar Itens</a></li>
        
      </ul><br>
    
    </div>

    <div class="col-sm-10">
      <h3>Cadastrar Produtos</h3>
      <hr>
      <form method="post" action="controller/cadastrarItensController.php">   
                <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" class="form-control" id="nome" placeholder="Insira o nome do produto" name="nome" required="">
                </div>
                <div class="form-group">
                <label for="descricao">Descriçao:</label>
                <input type="text" class="form-control" id="descricao" placeholder="Insira a descriçao do produto" name="descrica" required="">
                </div>
                <div class="form-group">
                <label for="quantidade">Quantidade:</label>
                <input type="number" class="form-control" id="quantidade" placeholder="Insira a quantidade do produto" name="quantidade" required="">
                </div>
                <div class="form-group">
                <label for="precoCusto">Preco de Custo:</label>
                <input type="text" class="form-control" id="precoCusto" placeholder="Insira o preco de custo do produto" name="precoCusto" required="">
                </div>
                <div class="form-group">
                <label for="precoVenda">Preco da Venda:</label>
                <input type="text" class="form-control" id="precoVenda" placeholder="Insira o preco da venda do produto" name="precoVenda" required="">
                </div>
            
               <label for="img">img:</label>
                <input type="text" class="form-control" id="img" placeholder="Insira o nome do produto" name="img" required="">
             
              <br>
                <div class="d-grid">
                   <button type="submit"class="btn btn-info">Entrar</button>
                 </div></form>
    </div>   

   
   

</body>
</html>
