<!DOCTYPE html>
<?php
require_once './model/ConexaoMysql.php';
require_once './shared/header.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>carrinho</title>
        <style>
.col-sm-8{
    text-align: center;
}
        </style>
    </head>
    <body>
      <div class="row">
      <div class="col-sm-2"></div>
      <div class="col-sm-8">
      <h4>ITEM ADICIONADO AO CARRINHO</h4>
<?php

//require_once './model/itensModel.php';

if($_REQUEST['idItemCarrinho']){

 $itemId = $_GET['idItemCarrinho']; 

   $item = loadById($itemId);

foreach ($item as $item) {
    echo '<div class="item">';
    echo '<img src="';
    echo $item['img'];
    echo '" width="10%">';
    echo '<h3>';
    echo $item['nome'];
    echo '</h3>';
        echo '<h4>';
        echo 'R$';
            echo $item['precoVenda'];
        echo '</h4>';
        echo '<p>';
            echo 'Quantidade: ';
            echo $item['quantidade'];
echo '<br>';
echo '</div>';

}}

 ?>


<button  class="btn btn-default"><a href="index.php"> CONTINUAR COMPRANDO</a></button>
<button  class="btn btn-default"><a href="carrinho.php">IR AO CARRINHO</a></button>



      </div>
      </div>
      </div>
 <?php 
      

 function loadById($itemId) {

    //Criar um objeto de conexão
    $db = new ConexaoMysql();

    //Abrir conexão com banco de dados
    $db->Conectar();

    //Criar consulta
    $sql = 'SELECT * FROM itens where id =' . $itemId;
    //Executar método de consulta
    $resultList = $db->Consultar($sql);

    $db->Desconectar();

    return $resultList;
}

      ?>
    </body>
</html>
