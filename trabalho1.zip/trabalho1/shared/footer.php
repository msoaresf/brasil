<style>
  .footer{
      background:#34383c;
      text-align: center;
      color: #d1e7dd;  
  }
</style>
<div class="row">
<div class="footer">
    <div class="col-sm-12">
        <p>Dsfasfas</p>
    </div>
    </div>
</div>