<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>carrinho</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <style>
            body{
                font-family:Verdana, Geneva, Tahoma, sans-serif;
                position: relative; 


            }
            header{
                padding-top: 20px;
                width: 100%;
                position: fixed;
                background-color: white; 
                z-index: 1;
            }
            header li{
                display: inline;
                padding-left: 2%;
                color: #daa520;
            }
            header a{
                text-decoration: none;
                color:#daa520;
                font-family:Verdana, Geneva, Tahoma, sans-serif;
                font-size: 130%;
            }
        </style>
    </head>
    <body>
        <header>
            <ul>
                <li><a href="index.php">SHIUUMA</a></li>
                <li><a href="itens.php">Itens</a></li>
                <li><a href="cadastroUsuario.php">Cadastro</a></li>
                <li style="padding-left:70%;  "><a href="carrinho.php">Carrinho</a></li>
            </ul>
           
        </header>
 <br><br><br><br>