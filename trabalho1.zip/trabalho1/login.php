<?php 
require_once './shared/header.php';
?>
<style>
    body{
        font-family:Verdana, Geneva, Tahoma, sans-serif;
    }
 .col-sm-8{
            text-align: center;
            font-family:Verdana, Geneva, Tahoma, sans-serif;
            font-size: 130%;
            
 }

.login{
    font-family:Verdana, Geneva, Tahoma, sans-serif;
    border-radius: 4%;
    border:groove;
    padding: 5%;
   
}


</style>

<div class="container">
<div class="row"><br><br><br><br>
    <div class="col-sm-4"></div>
     <div class="col-sm-4">
      <div class="login">
      <h1>Login</h1>
                <br>
                  
      <form method="post" action="controller/loginController.php">   
                <div class="form-group">
                <label for="nome">Email:</label>
                <?php
                    //cookies no email
                    if (isset($_COOKIE['email'])) {
                        echo('<input type="email" class="form-control" id="email" 
                           placeholder="Insira seu email" name="email"
                            value="'.$_COOKIE['email'].'" required="">');
                    } else {
                        echo('<input type="email" class="form-control" id="email" 
                           placeholder="Insira seu email" name="email" required="">');
                    }
                    ?>     
                </div>
                <div class="form-group">
                    <label for="descricao">Senha:</label>
                    <input type="password" class="form-control" id="senha"  placeholder="Senha" name="senha" required=""> 
                </div> 
                <?php
                    //botao para lembrar
                    if (isset($_COOKIE['email'])) {
                        echo ('<input type="checkbox" class="form-check-input" id="lembrar" 
                           name="lembrar" checked value="1">');
                    } else {
                        echo ('<input type="checkbox" class="form-check-input" id="lembrar" 
                           name="lembrar" value="1">');
                    }
                    ?>
                    <label for="lembrar" style="color: black" class="form-check-label">Lembre de mim</label>
                  
              <br>
                <div class="d-grid">
                   <button type="submit"class="btn btn-info">Entrar</button>
                 </div></form>
                 <p>Não possui conta? <a href="cadastroUsuario.php">Cadastrar-se</a></P>
                 <?php
                @$cod = $_REQUEST['cod'];
                if(isset($cod)){
                      
                        if ($cod == '171') {
                            echo ('<br><div class="alert alert-danger">');
                            echo ('Verifique usuário ou senha.');
                            echo ('</div>');
                        } else if ($cod == '172') {
                            echo ('<br><div class="alert alert-warning">');
                            echo ('Sua sessão expirou. Realize o login novamente.');
                            echo ('</div>');
                        }
                        else if ($cod == '173') {
                            echo ('<br><div class="alert alert-warning">');
                            echo ('Verifique status do usuario.');
                            echo ('</div>');
                        }
                    }
                    ?>

  </div>
 </div>
</div>

</div>

