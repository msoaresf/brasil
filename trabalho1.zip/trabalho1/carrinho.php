<!DOCTYPE html>
<?php
require_once './shared/header.php';
require_once './model/ConexaoMysql.php';
require_once './model/itensModel.php'; // Incluir o arquivo de modelo de itens
session_start();
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Carrinho</title>
        <style>
        </style>
    </head>
    <body>

        <div class="row">
            <div class="col-sm-3"></div>
            <div class="col-sm-6">
        
                <h2>Carrinho</h2>
                            
                <form method="post" action="controller/salvarCompra.php">
                <table class="table">
                    <thead>
                        <tr>
                            <th>PRODUTO<th>
                            <th>QUANTIDADE<th>
                            <th>VALOR UNITÁRIO<th>
                            <th>VALOR TOTAL<th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                      
                        $totalCarrinho = 0;
                        if (!empty($_SESSION['carrinho'])) {
                            foreach ($_SESSION['carrinho'] as $itemId => $quantidade) {
                                $item = loadById($itemId);
                                if ($item) {
                                    echo '<tr>';
                                    echo '<td>';
                                    echo '<img src="' . $item['img'] . '" width="30%">';
                                    echo '</td>';
                                    echo '<td>';
                                    echo '<h4>' . $item['nome'] . '</h4>';
                                    echo '<input type="number"  style="width:40%; height: 100%;" value="' . $quantidade . '">';
                                    echo '</td>';
                                    echo '<td>';
                                    echo 'R$' . $item['precoVenda'];
                                    echo '</td>';
                                    $subtotal = $item['precoVenda'] * $quantidade;
                                    echo '<td>';
                                    echo 'R$' . $subtotal;
                                    echo '</td>';
                                    echo '</tr>';
                                    $totalCarrinho += $subtotal;
                                }
                            }
                        }
                        ?>
                    </tbody>
                </table>
                <hr>
                <div><h4 style="display:inline;">Total do Carrinho:</h4> R$<?php echo $totalCarrinho; ?><br><br>
             
                <input type="hidden" name="totalCarrinho" value="<?php echo $totalCarrinho; ?>">
                <button class="btn btn-success" type="submit" name="salvarCompra" value="Salvar Compra">FINALIZAR COMPRA</button>

            </form>
                <form method="post" action="controller/limparController.php"><br><br>
                    <button class="btn btn-default" type="submit" name="limpar_carrinho" value="Limpar Carrinho">Limpar Carrinho</button>
                </form>
              
                <?php
                if(isset($cod)){
                      if ($cod == '100') {
                          echo ('<br><div class="alert alert-alert">');
                          echo ('Compra pendente, agurde confirmação');
                          echo ('</div>');
                     } }?>    
            </div>     </div>

      

        <?php

        function loadById($itemId) {
            $db = new ConexaoMysql();
            $db->Conectar();
            $sql = 'SELECT * FROM itens where id =' . $itemId;
            $result = $db->Consultar($sql);
            $db->Desconectar();
            return $result->fetch_assoc(); // Retorna um array associativo
        }
        ?>
    </body>
</html>
