<?php
require_once './shared/header.php';
?>
<html lang="en">
    <head>
        <title>Shiuuma</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/main.css" rel="styleheet" type="text/css"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <style>


            .active {
                background-color: #b1e9a3;
            }

            .col-sm-8{
                text-align: center;
                font-size: 130%;

            }

            .container {
                position: relative;
                width: 100%;
            }

            button{
                position: absolute;
                bottom: 10%;
                left: 8%;
                width: 25%;
                background-color: #ffffffd7;
                border-radius: 2px;
            }
            a{
                text-decoration: none;
                color:#a3c485fd;
                font-size: 150%;

            }



        </style>
        <div class="imgBanner">
            <img src="img/banner.jpg" width="100%" ></div><br>
        <div class="row"><hr>
            <div class="col-sm-2"></div>
            <div class="col-sm-8"><br>
                <h3>Perfumaria</h3>
                <p>Nosso jeito único de levar fragrâncias até a sua casa!! combinamos arte, natureza e tecnologia para que você tenha uma experiência inesquecível!</p>

            </div>
            <div class="col-sm-2"></div>
        </div>
        <div class="row">
            <div class="col-sm-2"></div>
            <div class="col-sm-8"><br><hr><br>
                <h3>Skincare</h3>
                <p>Descubra uma nova maneira de cuidar da sua pele com a nossa linha de produtos de skincare. Combinamos ingredientes naturais e avanços tecnológicos para criar fórmulas eficazes que proporcionam resultados visíveis. Experimente agora e eleve sua rotina de cuidados com a pele a um novo patamar de beleza e bem-estar. </p>          <br><br><br>
            </div>
            <div class="col-sm-2"></div>
        </div>
        <div class="row">
            <div class="col-sm-2"></div>
            <div class="col-sm-8"><hr><br>
                <h3>Cabelos</h3>
                <p>Explore uma nova abordagem para o cuidado dos seus cabelos com nossos produtos exclusivos. Experimente agora e descubra o segredo por trás de cabelos saudáveis e radiantes.</p>
                <br><br><br>
            </div>
            <div class="col-sm-2"></div>
        </div>
        <hr><br><br>
        <div class="container">   
        <div class="row">
            <div class="col-sm-4">
                    <img  src="img/perfumeIndex.webp" width="100%" alt="alt"/>
            
            </div>
            <div class="col-sm-4">
                    <img src="img/skincareIndex.webp" width="100%" alt="alt"/>
            </div>
            <div class="col-sm-4">
                    <img src="img/cabelosIndex.avif" width="100%" alt="alt"/>
                   
                </div>
            </div>
        </div>
        <br><br><br><br><hr>

        <?php require_once 'shared/footer.php' ?>
    </body>
</html>
