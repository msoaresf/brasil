<?php

require_once 'ConexaoMysql.php';

class itensModel {

 
    protected $id;
    protected $nome;
    protected $descricao;
    protected $quantidade;
    protected $precoCusto;
    protected $precoVenda;
    protected $dataCadastro;
    protected $img;

    /**
     * Get the value of id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId($id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of nome
     */
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     */
    public function setNome($nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of descricao
     */
    public function getDescricao()
    {
        return $this->descricao;
    }

    /**
     * Set the value of descricao
     */
    public function setDescricao($descricao): self
    {
        $this->descricao = $descricao;

        return $this;
    }

    /**
     * Get the value of quantidade
     */
    public function getQuantidade()
    {
        return $this->quantidade;
    }

    /**
     * Set the value of quantidade
     */
    public function setQuantidade($quantidade): self
    {
        $this->quantidade = $quantidade;

        return $this;
    }

    /**
     * Get the value of precoCusto
     */
    public function getPrecoCusto()
    {
        return $this->precoCusto;
    }

    /**
     * Set the value of precoCusto
     */
    public function setPrecoCusto($precoCusto): self
    {
        $this->precoCusto = $precoCusto;

        return $this;
    }

    /**
     * Get the value of precoVenda
     */
    public function getPrecoVenda()
    {
        return $this->precoVenda;
    }

    /**
     * Set the value of precoVenda
     */
    public function setPrecoVenda($precoVenda): self
    {
        $this->precoVenda = $precoVenda;

        return $this;
    }

    /**
     * Get the value of dataCadastro
     */
    public function getDataCadastro()
    {
        return $this->dataCadastro;
    }

    /**
     * Set the value of dataCadastro
     */
    public function setDataCadastro($dataCadastro): self
    {
        $this->dataCadastro = $dataCadastro;

        return $this;
    }

    /**
     * Get the value of img
     */
    public function getImg()
    {
        return $this->img;
    }

    /**
     * Set the value of img
     */
    public function setImg($img): self
    {
        $this->img = $img;

        return $this;
    }



//Método construtor
public function __construct() {
        
}

//Métodos especialistas
public function loadAll() {

    //Criar um objeto de conexão
    $db = new ConexaoMysql();

    //Abrir conexão com banco de dados
    $db->Conectar();

    //Criar consulta
    $sql = 'SELECT * FROM itens';
    //Executar método de consulta
    $resultList = $db->Consultar($sql);

    //Desconectar do banco
    $db->Desconectar();

    return $resultList;
}

/*
 * Carrega a itens pelo identificador único
 */

public function loadById($id) {

    //Criar um objeto de conexão
    $db = new ConexaoMysql();

    //Abrir conexão com banco de dados
    $db->Conectar();

    //Criar consulta
    $sql = 'SELECT * FROM itens where id =' . $id;
    //Executar método de consulta
    $resultList = $db->Consultar($sql);

    //Verifica se retornou um registro da base de dados
    if ($db->total == 1) {
        //Se retornou preenche as propriedades de itens
        foreach ($resultList as $value) {
            $this->id = $value['id'];
            $this->nome = $value['nome'];
            $this->descricao = $value['descricao'];
            $this->quantidade= $value['quantidade'];
            $this->precoCusto = $value['precoCusto'];
            $this->precoVenda = $value['precoVenda']; 
            $this->dataCadastro = $value['dataCadastro'];
            $this->img = $value['img'];
        }
    }


    //Desconectar do banco
    $db->Desconectar();

    return $resultList;
}

public function insert() {

    //Criar um objeto de conexão
    $db = new ConexaoMysql();

    //Abrir conexão com banco de dados
    $db->Conectar();

    //Criar consulta
    
    $sql = 'INSERT INTO itens '
            . 'values(0,"' . $this->nome . '",'
            . '"' . $this->descricao . '",'
            . '"' . $this->quantidade . '",'
            . '"' . $this->precoCusto . '",'
            . '"' . $this->precoVenda . '",'
            . '"' . $this->dataCadastro. '",'
            . '"' . $this->img . '")';
    //Executar método de inserção
    $db->Executar($sql);

    //Desconectar do banco
    $db->Desconectar();

    return $db->total;
}



public function delete() {

    //Criar um objeto de conexão
    $db = new ConexaoMysql();

    //Abrir conexão com banco de dados
    $db->Conectar();

    //$sql = 'DELETE FROM racas WHERE id=';
    $sql = 'DELETE FROM itens WHERE id='.$this->id;
  

    //Executar método de inserção
    $db->Executar($sql);

    //Desconectar do banco
    $db->Desconectar();

    return $db->total;
}

function cadastrarItem($nome,$descricao, $quantidade,$precoCusto,$precoVenda,$img) {
   
    $db = new ConexaoMysql();
     $db->Conectar();
 
 //insere
     $sql = "INSERT INTO itens (id,nome,descricao, quantidade,precoCusto,precoVenda,dataCadastro,img, tipoUsuarioId) VALUES (0,'$nome','$descricao', '$quantidade','$precoCusto','$precoVenda','NOW()','img/$img',0)";
     
   
     $db->Executar($sql);
 
       
         $db->Desconectar();
 
         return $db->total;
 
   
   
      $resultList = $db->Consultar($sql);
 
     // Fechar a conexão com o banco de dados
       $db->Desconectar();
 
     return $resultList;
 }
 

}



  
