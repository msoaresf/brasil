<?php
require_once 'ConexaoMysql.php';
class pedidosModel {
    protected $id;
    protected $dataCompra;
    protected $valorTotal;
    protected $usuarioId;
    protected $statusId;
    
    public function __construct() {
        
    }
    public function getId() {
        return $this->id;
    }
    public function getDataCompra(){
        return$this->dataCompra;
    }

    public function getValorTotal() {
        return $this->valorTotal;
    }

    public function getUsuarioId() {
        return $this->usuarioId;
    }

    public function getStatusId() {
        return $this->statusId;
    }

    public function setId($id): void {
        $this->id = $id;
    }
    
    public function setDataCompra($dataCompra): void {
        $this->dataCompra = $dataCompra;
    }

    public function setValorTotal($valorTotal): void {
        $this->valorTotal = $valorTotal;
    }

    public function setUsuarioId($usuarioId): void {
        $this->usuarioId = $usuarioId;
    }

    public function setStatusId($statusId): void {
        $this->statusId = $statusId;
    }
    
    
    
public function loadAll() {

        //Criar um objeto de conexão
        $db = new ConexaoMysql();

        //Abrir conexão com banco de dados
        $db->Conectar();

        //Criar consulta
        $sql = 'SELECT * FROM pedidos';
        //Executar método de consulta
        $resultList = $db->Consultar($sql);

        //Desconectar do banco
        $db->Desconectar();

        return $resultList;
    }

    /*
     * Carrega a usuario pelo identificador único
     */


function salvarCompra($valorTotal,$usuarioId) {
   
   $db = new ConexaoMysql();
    $db->Conectar();
 
//insere
    $sql = "INSERT INTO pedidos (id,dataCompra,valorTotal, usuarioId, statusId) VALUES (0, 'NOW()','$valorTotal', '$usuarioId', 1)";
    
    $db->Executar($sql);

      
    $db->Desconectar();

    return $db->total;

  
  
     $resultList = $db->Consultar($sql);

    // Fechar a conexão com o banco de dados
      $db->Desconectar();

    return $resultList;
}

public function loadAllPedidos() {

    //Criar um objeto de conexão
    $db = new ConexaoMysql();

    //Abrir conexão com banco de dados
    $db->Conectar();

    //Criar consulta
    $sql = 'SELECT * FROM pedidos';
    //Executar método de consulta
    $resultList = $db->Consultar($sql);

    //Desconectar do banco
    $db->Desconectar();

    return $resultList;
}

    
    
public function update($pedidoId, $statusId) {
    //Criar um objeto de conexão
    $db = new ConexaoMysql();

    //Abrir conexão com banco de dados
    $db->Conectar();

    // Construir a consulta SQL
    $sql = 'UPDATE pedidos SET statusId = "' . $statusId . '" WHERE id = ' . $pedidoId;

    // Executar a consulta SQL
    $db->Executar($sql);

    // Desconectar do banco de dados
    $db->Desconectar();

    // Retornar o número de linhas afetadas (ou outro indicador de sucesso, se preferir)
    return $db->total;
}

}