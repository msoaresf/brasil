<?php 
require_once './shared/header.php';
?>

<html lang="en">
<head>
  <title>Shiuuma</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/main.css" rel="styleheet" type="text/css"/>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    <style>
    body{
        font-family:Verdana, Geneva, Tahoma, sans-serif;
    }
 .col-sm-8{
            text-align: center;
            font-family:Verdana, Geneva, Tahoma, sans-serif;
            font-size: 130%;
            
 }

.login{
    font-family:Verdana, Geneva, Tahoma, sans-serif;
    border-radius: 4%;
    border:groove;
    padding: 5%;
   
}



</style>

<div class="container">
<div class="row"><br><br><br>
    <div class="col-sm-4"></div>
     <div class="col-sm-4">
   
      <div class="login">
      <h1>Cadastro Usuario</h1>
      <form method="post" action="controller/usuarioController.php">       
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" class="form-control" id="nome" placeholder="Nome" name="nome" required="">
                </div>
                <div class="form-group">
                    <label for="nome">Email:</label>
                    <input type="texr" class="form-control" id="email" placeholder="Email" name="email" required="">
                </div>
                <div class="form-group">
                    <label for="descricao">Senha:</label>
                    <input type="password" class="form-control" id="senha"  placeholder="Senha" name="senha" required=""> 
                </div> 
                <p>Possui conta? <a href="login.php">Login</a></P>
                <div class="d-grid">
                   <button type="submit"class="btn btn-info">Entrar</button>
                 </div></form>

<br>
<br>
<br>
</div>
 </div>
</div>

</div>

<br>
<br>
<br>
<br>