create database banco;
use banco;

create table tipoUsuario(
id int auto_increment not null,
nome varchar(40),
primary key (id)
);

create table usuario(
id int auto_increment not null,
nome varchar(40),
email varchar(40),
senha varchar(40),
tipoUsuarioId int, 
foreign key (tipoUsuarioId) references tipoUsuario(id),
primary key (id));

create table itens(
id int auto_increment not null,
nome varchar(40),
descricao varchar(60),
quantidade int,
precoCusto varchar(30),
precoVenda varchar(30),
dataCadastro date,
img varchar(100),
usuarioId int,
foreign key(usuarioId) references usuario(id),
primary key (id)
);
create table statusPedido(
id int auto_increment not null,
status varchar(45),
primary key (id)
);
create table pedidos(
id int auto_increment not null,
dataCompra datetime,
dataAprovacao datetime,
valorTotal Float,
usuarioId int,
statusId int,
foreign key(statusId) references statusPedido(id),
primary key (id)
);
create table carrinho(
id int auto_increment not null,
usuarioCarrinho int,
itensCarrinho int, 
foreign key (itensCarrinho) references itens(id),
foreign key (usuarioCarrinho) references usuario(id),
primary key (id));

INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('LANCOME', 'perfume lancôme la vie est belle feminino', '12', '200,00', 'R$309,00', '2020-08-12', 'img/perfume1.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('GUCCI', 'perfume gucci gucci guilty pout homme masculino', '8', '500,00', 'R$909,00', '2019-09-29', 'img/perfume2.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('212 VIP', 'perfume carolina herrera 212 vip rosé feminino', '76', '230,00', 'R$449,00', '2022-05-23', 'img/perfume3.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('PRADA', 'perfume prada paradoxe intense feminino', '54', '380,00', 'R$619,00', '2021-06-27', 'img/perfume4.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('LANCOME', 'perfume lancôme la vie est belle rose extraordinaire', '5', '460,00', 'R$679,00', '2021-05-02', 'img/perfume5.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('YVES SAINT LAURENT', 'perfume libre l\'absolu platine', '34', '450,00', 'R$959,0', '2021-06-28', 'img/perfume6.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('DIOR', 'Creme facial noturno Dior prestige midnigth', '5', '4500,00', 'R$5.345,00', '2021-06-28', 'img/skincare1.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('CARE', 'Oleo facial regenerador noturnocare natural beauty', '6', '150,00', 'R$249,00', '2021-06-28', 'img/skincare2.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('BANILA', 'BALM DE LIMPEZA BANILA CO CLEAN IT ZERO BRIGHTENING', '4', '150,00', 'R$240,00', '2021-06-28', 'img/skincare3.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('FOREO', 'Esponja eletrica facial Foreo', '54', '450,00', 'R$599,40', '2021-06-28', 'img/skincare4.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('DRUNK ELEPHANT', 'Creme hidratante facial drunk elephant lala retro ', '3', '450,00', 'R$545,00', '2021-06-28', 'img/skincare5.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('DRUNK ELEPHANT', 'Serum iluminador drunk elephant b-goldi bright', '4', '250,00', 'R$315,00', '2021-06-28', 'img/skincare6.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('BRAÉ HAIR', 'mascara capilar braé blond repair', '7', '50,00', 'R$132,00', '2021-06-28', 'img/cabelo1.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('TANGLE TEEZER', 'escova de cabelo tangle teezer wet detangler', '7', '80,00', 'R$135,00', '2021-06-28', 'img/cabelo2.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('WELLA', 'macara de hidrataçao capilar wella', '9', '90,00', 'R$260,00', '2021-06-28', 'img/cabelo3.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('OCEANE', 'finalizador capilar para cabelos cacheados oceane', '23', '200,00', 'R$360,00', '2021-06-28', 'img/cabelo4.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('NIOXIN', 'shampoo para cabelos loiros nioxin', '4', '120,00', 'R$180,00', '2021-06-28', 'img/cabelo5.avif');
INSERT INTO `banco`.`itens` (`nome`, `descricao`, `quantidade`, `precoCusto`, `precoVenda`, `dataCadastro`, `img`) VALUES ('KÉRASTASE', 'shampoo hidratante para cabelos coloridos kerastase', '64', '120,00', 'R$260,00', '2021-06-28', 'img/cabelo6.avif');

INSERT INTO `banco`.`tipousuario` (`nome`) VALUES ('client');
INSERT INTO `banco`.`tipousuario` (`nome`) VALUES ('adm');

INSERT INTO `banco`.`statuspedido` (`status`) VALUES ('pendentente');
INSERT INTO `banco`.`statuspedido` (`status`) VALUES ('finalizado');
UPDATE `banco`.`statuspedido` SET `status` = 'aprovado' WHERE (`id` = '2');
INSERT INTO `banco`.`statuspedido` (`status`) VALUES ('recusado');

UPDATE `banco`.`itens` SET `precoVenda` = '309' WHERE (`id` = '1');
UPDATE `banco`.`itens` SET `precoVenda` = '909' WHERE (`id` = '2');
UPDATE `banco`.`itens` SET `precoVenda` = '449' WHERE (`id` = '3');
UPDATE `banco`.`itens` SET `precoVenda` = '619' WHERE (`id` = '4');
UPDATE `banco`.`itens` SET `precoVenda` = '679' WHERE (`id` = '5');
UPDATE `banco`.`itens` SET `precoVenda` = '959' WHERE (`id` = '6');
UPDATE `banco`.`itens` SET `precoVenda` = '5345' WHERE (`id` = '7');
UPDATE `banco`.`itens` SET `precoVenda` = '249' WHERE (`id` = '8');
UPDATE `banco`.`itens` SET `precoVenda` = '240' WHERE (`id` = '9');
UPDATE `banco`.`itens` SET `precoVenda` = '599' WHERE (`id` = '10');
UPDATE `banco`.`itens` SET `precoVenda` = '545' WHERE (`id` = '11');
UPDATE `banco`.`itens` SET `precoVenda` = '315' WHERE (`id` = '12');
UPDATE `banco`.`itens` SET `precoVenda` = '132' WHERE (`id` = '13');
UPDATE `banco`.`itens` SET `precoVenda` = '135' WHERE (`id` = '14');
UPDATE `banco`.`itens` SET `precoVenda` = '260' WHERE (`id` = '15');
UPDATE `banco`.`itens` SET `precoVenda` = '360' WHERE (`id` = '16');
UPDATE `banco`.`itens` SET `precoVenda` = '180' WHERE (`id` = '17');
UPDATE `banco`.`itens` SET `precoVenda` = '260' WHERE (`id` = '18');

ALTER TABLE `banco`.`pedidos` 
DROP COLUMN `dataAprovacao`;
