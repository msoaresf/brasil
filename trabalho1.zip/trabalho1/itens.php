<?php 
require_once './shared/header.php';
?>
<html lang="en">
<head>
  <title>Shiuuma</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/main.css" rel="styleheet" type="text/css"/>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
  <style>
   
  body {
    position: relative; 
    background-color: #f8f9fa;
  }

  .fundo{
    border-radius: 4%;
    background-color: rgba(171, 204, 149, 0.452);
    padding: 1%;
    text-align: center;
    font-family:Verdana, Geneva, Tahoma, sans-serif;
    font-size: 90%;
    color:#fff;
    height: 25%;
    width: 17%;
    position: fixed;
    
  
}
.item{
    padding-left:2%;
    border:groove;
    border-radius: 2%;
    border-color: #daa520; 
    padding: 40px;
    text-align: center;
    background-color: #fff;
}


.buttonbtn{
    border-radius: 3px;
    color: #daa520;
    background-color: #fff;
    width: 80%;
    border-color: #daa520; 
    padding: 4%;
        
}
.buttonbtn a{
    text-decoration: none;
    color: #daa520;
 
}
h2{
    text-align: center;
}

</style> 

<body>
    <main class="container">
        <h2>PRODUTOS</h2>
        <br><form action="" method="">            
        <div class="input-group">
        <input type="text" class="form-control" placeholder="Pesquisar produto" id=""/>
        <div class="input-group-btn">
        <button class="btn btn-primary" type="submit">
        <span class="glyphicon glyphicon-search"></span>
        </button>
   </div>
   </div>
</form>
        <br>
        <br>
        <br>
        <br>
    <?php
            require_once './controller/itensController.php';
            $itensList = loadAll();
            //Exibir resultado
            foreach ($itensList as $itens) {
                echo '<div class="col-sm-4">';
                echo '<div class="item">';
                echo '<img src="';
                echo $itens['img'];
                echo '" width="50%">';
                echo '</td>';
                echo '<h3>';
                echo $itens['nome'];
                echo '</h3>';
                    echo '<h4>';
                    echo 'R$';
                        echo $itens['precoVenda'];
                    echo '</h4>';
                    echo '<p>';
                        echo 'Quantidade: ';
                        echo $itens['quantidade'];
                    echo '</p>';
                    echo '<button class="buttonbtn"><a href="./controller/carrinhoController.php?itensId='.$itens['id'].'"> Adicionar ao carrinho</a></button>';
                    echo '</div>';
            echo '<br>';
            echo '</div>';


            }
            echo '<br>';
            ?></main>
    </body>

</html>

  