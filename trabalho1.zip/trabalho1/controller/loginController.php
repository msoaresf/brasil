<?php
if ($_POST) {
    // Verifica se o usuário preencheu o campo com email e senha
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    @$lembrar = $_POST['lembrar'];

    require_once '../Model/usuarioModel.php';
    $usuario = new usuarioModel();
    $result = $usuario->login($email, $senha);

    if ($result) {
        session_start();

        $_SESSION['usuarioId'] = $usuario->getId();
        $_SESSION['login'] = $email;
        $_SESSION['tipoUsuarioId'] = $usuario->getTipoUsuarioId(); // Adiciona o tipo de usuário à sessão

        if (isset($lembrar) && $lembrar == 1) {
            // Se lembrar está marcado, cria o cookie
            setcookie('email', $email, time() + (86400 * 30), "/");
        } else {
            // Se não, remove o cookie
            setcookie('email', "", time() - (86400 * 30), "/");
        }

        // Agora que você tem o tipo de usuário na sessão, pode redirecionar com base nele
        if ($_SESSION['tipoUsuarioId'] == 2) {
            // Redireciona para a página do administrador
            header('location:../adm.php');
            exit;
        } else if ($_SESSION['tipoUsuarioId'] == 1) {
            // Redireciona para a página inicial (index)
            header('location:../index.php');
            exit;
        }
    } else {
        // Se o login falhar, redireciona para a página de login com um código de erro
        header('location:../index.php?cod=171');
        exit;
    }
} else {
    // Se não houver uma solicitação HTTP POST, redireciona de volta para a página inicial
    header('location:../index.php');
    exit;
}
?>
