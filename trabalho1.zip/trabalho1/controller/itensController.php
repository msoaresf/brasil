<?php

if ($_POST) {

    require_once '../model/itensModel.php';
    $itens = new itensModel();
    $itens->setNome($_POST['nome']);
    $itens->setDescricao($_POST['descricao']);
    $itens->setQuantidade($_POST['quantidade']);
    $itens->setPrecoCusto($_POST['precoCusto']);
    $itens->setPrecoVenda($_POST['precoVenda']);
    $itens->setDataCadastro($_POST['dataCadastro']);
    $itens->setImg($_POST['img']);

    //Configuro o id do objeto.
    $itens->setId($_POST['id']); //se for um novo registro vai ser sempre ''
    //Se a variável id que vier do form for vazia '' então insere um novo registro
    //Chamo para ver se o id do objeto é vazio.
    if (empty($itens->getId())) {
        //Insere um novo registro
        $total = $itens->insert();
    } else {
        //Atualiza o registro existente.
        $total = $itens->update();
    }

    //echo 'funcionou';

    if ($total == 1) {
        //Se estiver inserindo um novo registro somente exibo  a msg.
        if (empty($itens->getId())) {
            header('location:../cadastrarItens.php?cod=success');
        } else {
            //Atualizei e foi um sucesso
            header('location:../adm.php?cod=success');
        }
    } else {
        header('location:../cadastrarItens.php?cod=error');
    }
} else if ($_REQUEST) {
    //Se existir a query string cod e cod == del
    if (isset($_REQUEST['cod']) && $_REQUEST['cod'] == 'del') {
        //Importa a model
        require_once '../model/itensModel.php';
        //Cria o objeto racas
        $itens = new itensModel();
        //Se o comando for par excluir
        if (isset($_REQUEST['id']) && !empty($_REQUEST['id'])) {
            //configuro o id
            $itens->setId($_REQUEST['id']);
            //exclui em seguida
            $total = $itens->delete();
            if ($total == 1) {
                header('location:../adm.php?cod=success');
            }
        }
    }
} else {
    //Selecionar todos os registros
    loadAll();
}

function loadAll() {
    //Importo raças model
    require_once './model/itensModel.php';
    //Crio um objeto do tipo raças
    $itens = new itensModel();
    $itensList = $itens->loadAll();

    return $itensList;
}

function loadById($id) {
    //Importo raças model
    require_once './model/itensModel.php';
    //Crio um objeto do tipo raças
    $itens = new itensModel();

    //Executa o método para carregar por id
    $itens->loadById($id);

    //Retorna um objeto do tipo raças.... 
    return $itens;
}
