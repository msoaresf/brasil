<?php
if ($_POST) {
    require_once '../model/itensModel.php';

    $nome = $_POST["nome"];
    $descricao = $_POST["descricao"];
    $quantidade = $_POST["quantidade"];
    $precoCusto = $_POST["precoCusto"];
    $precoVenda = $_POST["precoVenda"];
    $img = $_POST["img"];

    $item = new itensModel();
    $item -> cadastrarItem($nome,$descricao, $quantidade,$precoCusto,$precoVenda,$img);

  
}
 header('location:../adm.php?cod=success');
