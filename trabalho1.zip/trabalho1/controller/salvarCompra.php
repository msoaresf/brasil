<?php
session_start();
if ($_POST) {
    require_once '../model/pedidosModel.php';
    require_once '../model/usuarioModel.php';

    $totalCarrinho = $_POST["totalCarrinho"];

    // Verifica se o usuário está logado e recupera o ID da sessão
    if (isset($_SESSION['usuarioId'])) {
        $usuarioId = $_SESSION['usuarioId'];
    } else {
        // Se o usuário não estiver logado, redireciona para a página de login ou exibe uma mensagem de erro
        die('Usuário não está logado.');
    }

    $pedidos = new pedidosModel();
    $pedidos->salvarCompra($totalCarrinho, $usuarioId);

    $_SESSION['carrinho'] = array();

    header('location:../carrinho.php?cod=100');

    exit();
} else {
    // Se o formulário não foi enviado corretamente, redireciona para o carrinho
    header('location:../carrinho.php');
    exit();
}
?>
