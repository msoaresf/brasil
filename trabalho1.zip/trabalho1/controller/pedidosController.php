<?php
if ($_POST) {
    require_once '../model/pedidosModel.php';

    $pedidoId = $_POST['pedidoId']; // Certifique-se de obter o pedidoId do formulário
    $statusId = $_POST['statusId'];

    $pedidos = new pedidosModel();
    $pedidos->update($pedidoId, $statusId); // Certifique-se de passar ambos os argumentos

    header('Location: ../adm.php');
    exit();
}
?>
