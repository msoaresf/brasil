<?php
session_start();

// Se não existir a session login
if (!isset($_SESSION['login'])) {
    header('Location: index.php?cod=172');
    exit; // Termina o script após o redirecionamento
}

// Verifica se o usuário é um administrador (tipoUsuarioId = 2)
if ($_SESSION['tipoUsuarioId'] != 2) {
    // Se o usuário não for um administrador, redireciona de volta para a página inicial com um código de erro
    header('Location: login.php?cod=173');
    exit; // Termina o script após o redirecionamento
}

// Se o usuário for um administrador, continua carregando a página do administrador normalmente
?>
