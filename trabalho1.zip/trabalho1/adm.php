<!DOCTYPE html>
<html lang="en">
<head>

    <?php
    require_once './controller/autenticar.php';
    ?>
  
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
    .row.content {height: 1500px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
      display: block;
      
    }
  
    /* Set black background color, white text and some padding */
    
   
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-2 sidenav">
      <h4>SHIUUMA</h4>
      <ul class="nav nav-pills nav-stacked">
        <li class="active"><a href="index.php">Pagina principal</a></li>
        <li><a href="adm.php">Pagina do administrador</a></li>
        <li><a href="cadastrarProduto.php">Cadastrar Itens</a></li>
        
      </ul><br>
    
    </div>

    <div class="col-sm-6">
      <h3>Produtos</h3>
      <hr>
      <table class="table table-bordered">
            <thead>
            <th>Produto</th>
            <th>Nome</th>
            <th>Descriçao</th>
            <th>Preços</th>
            <th>Operações</th>
        </thead>
        <tbody>
            <?php
            require_once './controller/itensController.php';
            $itensList = loadAll();
            //Exibir resultado
            foreach ($itensList as $itens) {
                echo '<tr>';
                echo '<td>';
                echo '<img src="';
                echo $itens['img'];
                echo '" width="30%" height="20%">';
                echo '</td>';
                    echo '<td>';
                        echo $itens['nome'];
                    echo '</td>';
                    echo '<td>';
                        echo $itens['descricao'];
                    echo '</td>';
                    echo '<td>';
                        echo 'Preço de Custo:';
                        echo $itens['precoCusto'];
                        echo '<br>';
                        echo 'Preço de Venda:';
                        echo $itens['precoVenda'];
                echo '</td>';
                    //Operações
                    echo '<td>';
                            echo '<a class="btn btn-danger" href="./controller/itensController.php?cod=del&&id='.$itens['id'].'">Excluir</a>';
                    echo '</td>';
                echo '</tr>';
            }

            $itens = loadById(10);
            ?>
        </tbody>
     </table>
      <script>
        $(document).ready(function () {
        $('#itensTable').DataTable({

        });
    </script>
      
      
   
     </div>

    <div class="col-sm-4">
     <h3>Cadastrar novo administrador</h3><hr>
     <form method="post" action="controller/amdController.php">   
                <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" class="form-control" id="nome" placeholder="Insira o nome do administrador" name="nome" required="">
                </div>
                <div class="form-group">
                <label for="email">Email:</label>
                <input type="text" class="form-control" id="email" placeholder="Insira o email" name="email" required="">
                </div>
                <div class="form-group">
                <label for="senha">Senha:</label>
                <input type="text" class="form-control" id="senha" placeholder="Insira o nome do produto" name="senha" required="">
                </div>
                <button type="submit"class="btn btn-default">Adicionar</button>
                <?php
                @$cod = $_REQUEST['cod'];
                if(isset($cod)){
              
                        if ($cod == '100') {
                            echo ('<br><br><div class="alert alert-success">');
                            echo ('Administrador adicionado com sucesso.');
                            echo ('</div>');
                        }}
                    
                    ?>
     </form>
     <br>
     <h3>Pedidos</h3><hr>
     <?php
                    require_once './controller/pedidosController.php';
                    require_once './model/pedidosModel.php';

    //Crio um objeto do tipo raças
                     $pedidos = new pedidosModel();
                     $pedidosList = $pedidos->loadAllPedidos();


                    foreach ($pedidosList as $pedidos) {
                        echo '<div class="pedido">';
                        echo '<tr>';
                        echo '<td><strong>Usuario: ' . $pedidos['usuarioId'] . '</strong><br>';
                        echo 'Valor da compra: R$' . $pedidos['valorTotal'] . ',00 <br>';
                        echo 'Data e Hora: ' . $pedidos['dataCompra'] . '</td>';
                        echo '<td>';
                        echo '<form method="post" action="controller/pedidosController.php">';
                        echo '<select class="form-control" name="statusId">';
                        echo '<option value="1"' . ($pedidos['statusId'] == 1 ? ' selected' : '') . '>Pendente</option>';
                        echo '<option value="2"' . ($pedidos['statusId'] == 2 ? ' selected' : '') . '>Aprovado</option>';
                        echo '<option value="3"' . ($pedidos['statusId'] == 3 ? ' selected' : '') . '>Recusado</option>';
                        echo '</select>';
                        echo '</td>';
                        echo '<td>';
                        echo '<input type="hidden" name="pedidoId" value="' . $pedidos['id'] . '">';
                        echo '<br><button type="submit" class="btn btn-primary">Atualizar</button>';
                        echo '</form>';
                        echo '</td>';
                        echo '</tr>';
                        echo '</br>';
                        echo '</div>';
                    }
                    ?>

</body>
</html>
