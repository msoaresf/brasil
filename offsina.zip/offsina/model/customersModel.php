<?php

namespace Model;
require_once 'conexaoMysql.php';

use ConexaoMysql;
use Exception;

class customersModel
{
 
    protected $id;
    protected $first_name;
    protected $last_name;
    protected $phone;
    protected $email;
    protected $address;
    protected $city;
    protected $state;
    protected $zip_code;
    protected $registration_date;
    
    //TODO feito: Insira as propriedades dos clientes aqui.
    

    //TODO feito: Crie os métodos acessores e modificadores aqui.


    public function __construct()
    {
        
    }
  

    /**
     * Get the value of id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId($id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of first_name
     */
    public function getFirstName()
    {
        return $this->first_name;
    }

    /**
     * Set the value of first_name
     */
    public function setFirstName($first_name): self
    {
        $this->first_name = $first_name;

        return $this;
    }

    /**
     * Get the value of last_name
     */
    public function getLastName()
    {
        return $this->last_name;
    }

    /**
     * Set the value of last_name
     */
    public function setLastName($last_name): self
    {
        $this->last_name = $last_name;

        return $this;
    }

    /**
     * Get the value of phone
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set the value of phone
     */
    public function setPhone($phone): self
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get the value of email
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set the value of email
     */
    public function setEmail($email): self
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get the value of address
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * Set the value of address
     */
    public function setAddress($address): self
    {
        $this->address = $address;

        return $this;
    }

    /**
     * Get the value of city
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * Set the value of city
     */
    public function setCity($city): self
    {
        $this->city = $city;

        return $this;
    }

    /**
     * Get the value of state
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set the value of state
     */
    public function setState($state): self
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get the value of zip_code
     */
    public function getZipCode()
    {
        return $this->zip_code;
    }

    /**
     * Set the value of zip_code
     */
    public function setZipCode($zip_code): self
    {
        $this->zip_code = $zip_code;

        return $this;
    }

    /**
     * Get the value of registration_date
     */
    public function getRegistrationDate()
    {
        return $this->registration_date;
    }

    /**
     * Set the value of registration_date
     */
    public function setRegistrationDate($registration_date): self
    {
        $this->registration_date = $registration_date;

        return $this;
    }

    
    public function loadAll(){
        $con = new ConexaoMysql();
        $con->Conectar();

        $sql = 'SELECT * FROM customers;';

        $resultList = $con->Consultar($sql);

        return $resultList;
    }

    public function getCustomerById($id){
        $com = new ConexaoMysql();
        $com-> Conectar();

        $sql = 'SELECT *  FROM customers where id = '.$id;
        $resultList = $com->Consultar($sql);

        if($com->total == 1){
            foreach($resultList as $customer){
                $this->setFirstName($customer['first_name']);
                return 1;
            }
        }else{
            return 0;
        }
    }
}
