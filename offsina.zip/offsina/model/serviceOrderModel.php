<?php


namespace Model;
require_once 'conexaoMysql.php';
use ConexaoMysql;
use Exception;

class serviceOrderModel
{
    protected $id;
    protected $descricao;
    protected $carroId;
    

    public function __construct()
    {
       
    }

    /**
     * Get the value of id
     */ 
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of firstName
     */ 
    public function getDescricao()
    {
        return $this->descricao;
    }

    /**
     * Set the value of firstName
     *
     * @return  self
     */ 
    public function setDescricao($descricao)
    {
        $this->descricao = $descricao;

        return $this;
    }

    /**
     * Get the value of lastName
     */ 
    public function getCarroId()
    {
        return $this->carroId;
    }

    /**
     * Set the value of lastName
     *
     * @return  self
     */ 
    public function setCarroId($carroId)
    {
        $this->carroId = $carroId;

        return $this;
    }
    
 
    
    function cadastrar($descricao,$carro) {
   
        $db = new ConexaoMysql();
        $db->Conectar();
     
        //insere
        $sql = "INSERT INTO serviceOrder (id, descricao, carro) VALUES (0,'$descricao','$carro')";
         
       
        $db->Executar($sql);
     
           
            $db->Desconectar();
     
            return $db->total;
     
       
       
        $resultList = $db->Consultar($sql);
     
         // Fechar a conexão com o banco de dados
           $db->Desconectar();
     
         return $resultList;
     }
     function loadAll() {

     }
     

}
