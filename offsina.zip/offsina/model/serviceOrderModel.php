<?php


namespace Model;
require_once 'conexaoMysql.php';
use ConexaoMysql;
use Exception;

class serviceOrderModel
{
    protected $id;
    protected $descricao;
    protected $carroId;
    public $total;

    public function __construct()
    {
       
    }

    public function getTotal()
    {
        return $this->total;
    }
    public function setTotal($total)
    {
        $this->total = $total;

        return $this;
    }
    



    /**
     * Get the value of id
     */ 
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }
    

    /**
     * Get the value of firstName
     */ 
    public function getDescricao()
    {
        return $this->descricao;
    }

    /**
     * Set the value of firstName
     *
     * @return  self
     */ 
    public function setDescricao($descricao)
    {
        $this->descricao = $descricao;

        return $this;
    }

    /**
     * Get the value of lastName
     */ 
    public function getCarroId()
    {
        return $this->carroId;
    }

    /**
     * Set the value of lastName
     *
     * @return  self
     */ 
    public function setCarroId($carroId)
    {
        $this->carroId = $carroId;

        return $this;
    }
    
 
    
    function cadastrar($descricao,$carro) {
   
        $db = new ConexaoMysql();
        $db->Conectar();
     
        //insere
        $sql = "INSERT INTO serviceOrder (id, descricao, carro, executada) VALUES (0,'$descricao','$carro',0)";
         
       
        $db->Executar($sql);
     
           
            $db->Desconectar();
     
            return $db->total;
     
       
       
        $resultList = $db->Consultar($sql);
     
         // Fechar a conexão com o banco de dados
           $db->Desconectar();
     
         return $resultList;
     }

   
    function loadAll(){
        $con = new ConexaoMysql();
        $con->Conectar();

        $sql = 'SELECT * FROM customers;';

        $resultList = $con->Consultar($sql);

        return $resultList;
    }
    
    function delete($id){
        $con = new ConexaoMysql();
        $con->Conectar();
        
        $this->id = $id;
        if($this->id > 0){
            $sql = 'DELETE FROM serviceorder WHERE id= '.$id;
        }
        $con->Executar($sql);
        //Atualiza o total de registros modificados pelo comando sql
        $this->total = $con->total;
        $con->Desconectar();
    }

    function executar($id){
        $con = new ConexaoMysql();
        $con->Conectar();
        
        $this->id = $id;
        if($this->id > 0){  
            $sql ='UPDATE serviceorder SET executada = 1 WHERE id ='.$id;
        }
        $con->Executar($sql);
        //Atualiza o total de registros modificados pelo comando sql
        $this->total = $con->total;
        $con->Desconectar();
    }


}
