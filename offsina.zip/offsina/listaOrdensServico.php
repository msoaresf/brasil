<?php
require_once './shared/header.php';
include_once './controller/autenticationController.php';
require_once './model/serviceOrderModel.php';

?>
<br>
<h1>Lista de ordens de serviço abertas</h1>
<a href="./listaVeiculos.php">Adicionar nova Ordem de serviço</a>
<div class="table-responsive">
    <table id="dataClients" class="table table-striped table-hover  table-primary align-middle">
        <thead class="table-light">
            <tr>
                <th>Veículo</th>
                <th>Problema</th>
                <th>Operações</th>
            </tr>
        </thead>
        <tbody class="table-group-divider">
        <?php
             include_once './controller/ordemServicoController.php';

            $ordensList = loadAll();
            //Exibir resultado
            foreach ($ordensList as $ordem) {
                echo '<tr class="table-primary">';
                echo'<td scope="row">';
                echo $ordem['carro'];
                echo'</td>';
                echo'<td scope="row">';
                echo $ordem['descricao'];
                echo'</td>';
                echo'<td scope="row">';
                echo '<a class="btn btn-success" href="./listaOrdensServico.php?cmd=executar&id='.$ordem['id'].'">Executar ordem de serviço</a>';
                echo ' | <a class="btn btn-danger" href="./listaOrdensServico.php?cmd=delete&id='.$ordem['id'].'">Excluir</a>';
                echo'</td>';
                echo'</tr>';
        }
        ?>    
        </tbody>
        <tfoot>

        </tfoot>
    </table>
    <p>Lista de ordens de serviço executadas</p>
    <div class="table-responsive">
    <table id="dataClients" class="table table-striped table-hover  table-primary align-middle">
        <thead class="table-light">
            <tr>
                <th>Veículo</th>
                <th>Problema</th>
                <th>Operações</th>
            </tr>
        </thead>
        <tbody class="table-group-divider">
        <?php
            include_once './controller/ordemServicoController.php';

            $ordensList = executadas();
            //Exibir resultado
            foreach ($ordensList as $ordem) {
                echo '<tr class="table-primary">';
                echo'<td scope="row">';
                echo $ordem['carro'];
                echo'</td>';
                echo'<td scope="row">';
                echo $ordem['descricao'];
                echo'</td>';
                echo'<td scope="row">';
                echo '<a class="btn btn-danger" href="./listaOrdensServico.php?cmd=delete&id='.$ordem['id'].'">Excluir</a> ';
                echo'</td>';
                echo'</tr>';
        }
        ?>    
        </tbody>
        <tfoot>

        </tfoot>
    </table>


<?php 
      @$cod = $_REQUEST['cod'];
      if(isset($cod)){
            
              if ($cod == 'success') {
                  echo ('<br><div class="alert alert-success">');
                  echo ('Registro deletado com sucesso.');
                  echo ('</div>');
              }else   if ($cod == 'successexe') {
                echo ('<br><div class="alert alert-success">');
                echo ('Registro executado com sucesso.');
                echo ('</div>');
            }
            }
    ?>
</div>
<?php
   
function loadAll(){
    $con = new ConexaoMysql();
    $con->Conectar();

    $sql = 'SELECT * FROM serviceOrder where executada = 0;';

    $resultList = $con->Consultar($sql);

    return $resultList;
}
function executadas(){
    $con = new ConexaoMysql();
    $con->Conectar();

    $sql = 'SELECT * FROM serviceOrder where executada = 1;';

    $resultList = $con->Consultar($sql);

    return $resultList;
}

require_once './shared/header.php';
?>