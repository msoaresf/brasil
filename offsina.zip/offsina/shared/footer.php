</main>
<footer class="footer text-center">
    <br>
    <h6 class="color:red;">©copyright 2024 - Todos os direitos reservados by 433. - Maria Eduarda Soares Ferreira</h6>
</footer>
</div>
</body>

</html>