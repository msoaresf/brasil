<?php
require_once './shared/header.php';
require_once './model/ConexaoMysql.php';
include_once './controller/autenticationController.php';
?>
<br>
<h1>Cadastro de ordens de serviço</h1>
<form action="controller/cadastrarOrder.php" method="POST">
<?php

if($_REQUEST['id']){

 $carroId = $_GET['id']; 

   $carro = loadById($carroId);

foreach ($carro as $carro) {


 ?>
<div class="mb-3">
        <label for="first_name" class="form-label">Veículo</label>
        <input type="text" class="form-control" id="veiculo" name="veiculo" value="<?php echo $carro['license_plate']; }}?>" required>
    </div>
    <div class="mb-3">
        <label for="problema" class="form-label">Problema/Defeito:</label>
        <textarea class="form-control" name="problema" id="problema" rows="5"></textarea>
    </div>
    
    <input type="submit" class="btn btn-primary" value="Cadastrar nova ordem de serviço">
    <input type="reset" class="btn btn-danger" value="Limpar campos">
    <br>
</form>

<?php
function loadById($carroId) {

    //Criar um objeto de conexão
    $db = new ConexaoMysql();

    //Abrir conexão com banco de dados
    $db->Conectar();

    //Criar consulta
    $sql = 'SELECT * FROM vehicles where id =' . $carroId;
    //Executar método de consulta
    $resultList = $db->Consultar($sql);

    $db->Desconectar();

    return $resultList;
}

require_once './shared/footer.php';
?>
