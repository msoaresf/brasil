<?php
require_once '../model/serviceOrderModel.php';
use model\serviceOrderModel;


if ($_POST) {

    $descricao = $_POST["problema"];
    $carro = $_POST["veiculo"];


    $service = new serviceOrderModel();
    $service -> cadastrar($descricao, $carro);

  
}

header('location:../listaOrdensServico.php');
