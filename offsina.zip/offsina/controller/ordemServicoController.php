<?php

use Model\serviceOrderModel;

if ($_REQUEST) {
    require_once './model/serviceOrderModel.php';
    $serviceOrder = new serviceOrderModel();
    //verifica o comando se é delete.
    @$cmd = $_REQUEST['cmd'];
    //Verifica se o id do registro a ser deletado ou editado  foi passado na query string.
    if (isset($_REQUEST['id'])) {
        $id = $_REQUEST['id'];
        if ($cmd == 'delete') {
            //Apaga
            $serviceOrder->delete($id);
            if ($serviceOrder->getTotal() > 0) {
                header('location:../offsina/listaOrdensServico.php?cod=success');
            } 
        }
        if ($cmd == 'executar') {
            //Apaga
            $serviceOrder->executar($id);
            if ($serviceOrder->getTotal() > 0) {
                header('location:../offsina/listaOrdensServico.php?cod=successexe');
            } 
        }
    }
}

?>