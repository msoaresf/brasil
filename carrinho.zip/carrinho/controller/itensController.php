<?php

    require_once './model/itensModel.php';
    $itens = new itensModel();
    $itens->setNome('nome');
    $itens->setQuantidade('quantidade');
    $itens->setPrecoVenda('precoVenda');


    //echo 

  function loadAll() {
    //Importo 
    require_once './model/itensModel.php';
    //Crio um objeto do tipo itens
    $itens = new itensModel();
    $itensList = $itens->loadAll();

    return $itensList;
}
