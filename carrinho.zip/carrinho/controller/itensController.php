<?php

    require_once './model/itensModel.php';
    $itens = new itensModel();
    $itens->setNome('nome');
    $itens->setQuantidade('quantidade');
    $itens->setPrecoVenda('precoVenda');


    //echo 

  function loadAll() {
    //Importo 
    require_once './model/itensModel.php';
    //Crio um objeto do tipo itens
    $itens = new itensModel();
    $itensList = $itens->loadAll();

    return $itensList;
}

function loadById($id) {
    //Importo raças model
    require_once './model/itensModel.php';
    //Crio um objeto do tipo raças
    $itens = new itensModel();

    //Executa o método para carregar por id
    $itens->loadById($id);

    //Retorna um objeto do tipo raças.... 
    return $itens;
}
