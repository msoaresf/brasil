<?php
    require_once 'p';

//Verifico se existe query string chamada produtoId
if($_REQUEST['id']){
    //Capturo o valor da query string produtoId e armazeno na var. local $produtoId
    $itensId = $_REQUEST['id'];
   
    //Mecanismo para criar o array
    @session_start();
    //Se não existir a sessão carrinho eu inicializo um array local.
    if(!isset($_SESSION['carrinho'])){
        $itens = array(); //criando o vetor itens
    }else{
        $itens = $_SESSION['carrinho'];
    }
    //Mecanismo para buscar o array
    //$encontrou =false;
    //foreach ( $itens as $key => $produtoAdicionado) {
       //if($produtoAdicionado == $produtoId){
            //$encontrou =true;
        //}
    //}

    //if(!$encontrou){
        $itens[] = $itensId;
        //$itens = sort($itens);
    //}

    $_SESSION['carrinho'] = $itens;

    echo 'Produto'.$itensId.' adicionado.';

    header('location:../itens.php');

}