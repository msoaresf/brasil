<?php
//Verifico se existe query string chamada produtoId
if($_REQUEST['itensId']){
    //Capturo o valor da query string produtoId e armazeno na var. local $produtoId
    $itemId = $_REQUEST['itensId'];
    

    //Mecanismo para criar o array
    @session_start();
    //Se não existir a sessão carrinho eu inicializo um array local.
    if(!isset($_SESSION['carrinho'])){
        $itens = array(); //criando o vetor itens
    }else{
        $itens = $_SESSION['carrinho'];
    }
    //adicionando o id do produto no array itens
        $itens[] = $itemId;
   
    $_SESSION['carrinho'] = $itens; 

    echo '<script>';
    echo 'alert("Produto adicionado ao carrinho")';
    echo '</script>'; 
  
    header('location:../confirmar.php?idItemCarrinho='.$itemId.'');

}