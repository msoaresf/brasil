<?php

if ($_POST) {
    require_once '../model/usuarioModel.php';

    $email = $_POST["email"];
    $senha = $_POST["senha"];
    $nome = $_POST["nome"];
    


    $usuario = new usuarioModel();
    $usuario -> cadastrar($nome,$email, $senha);

  
}
 header('location:../index.php');
