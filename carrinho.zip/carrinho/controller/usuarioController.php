<?php
if ($_POST) {
    require_once '../model/usuarioModel.php';

    $email = $_POST["email"];
    $senha = $_POST["senha"];


    $usuario = new usuarioModel();
    $usuario -> cadastrar($email, $senha);

  
}
 header('location:../index.php');
