<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>carrinho</title>
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <style>

            header{
                background-color: #F3F3F3;
                padding: 10px;
                        }
              li{
  display: inline;
  padding-left: 2%;
  width: 100%;
  height: 20%;
  color: black;
                }
        </style>
</head>
<body>
        <header>
           <ul>
               <li><a href="login.php">LOGIN</a></li>
               <li><a href="index.php">PRODUTOS</a></li>
               <li><a href="compra.php">HISTORICO DE COMPRAS</a></li>
               <li style="padding-left:60%; "><a href="carrinho.php">Carrinho</a></li>
        </ul>
        </header>