<!DOCTYPE html>
<?php
require_once './shared/header.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
      .backgroundCadastro{
          border-style: groove;
          padding: 5%;
          border-radius: 2%;
      }
  </style>
</head>
    <body>
        <div class="row"><br><br><br><br><br><br>
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
         <div class="backgroundCadastro">
         <h1>Cadastro Usuario</h1>
      <form method="post" action="controller/usuarioController.php">       
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" class="form-control" id="nome" placeholder="Nome" name="nome" required="">
                </div>
                <div class="form-group">
                    <label for="nome">Email:</label>
                    <input type="texr" class="form-control" id="email" placeholder="Email" name="email" required="">
                </div>
                <div class="form-group">
                    <label for="descricao">Senha:</label>
                    <input type="password" class="form-control" id="senha"  placeholder="Senha" name="senha" required=""> 
                </div> 
                <p>Possui conta? <a href="login.php">Login</a></P>
                <div class="d-grid">
                   <button type="submit"class="btn btn-defaut">Entrar</button>
                 </div></form>
        </div></div></div>

    </body>
</html>
