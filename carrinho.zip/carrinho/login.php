<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
       <style>
              .header{
  position: fixed;
  width: 100%;
  height: 20%;
  z-index:2;
}
    .backgroundCadastro{
          border-style: groove;
          padding: 5%;
          border-radius: 2%;
      }
        </style>
    
</head>
    <body>
        <div class="row"><div class="col-sm-4"></div>
            <div class="col-sm-4"><br><br><br><br><br><br>
                     <div class="backgroundCadastro">
          <form method="post" action="controller/loginController.php">   
              <h4>Login:</h4>  
              <div class="form-group">
                <label for="nome">Email:</label>
                <?php
                    //cookies no email
                    if (isset($_COOKIE['email'])) {
                        echo('<input type="email" class="form-control" id="email" 
                           placeholder="Insira seu email" name="email"
                            value="'.$_COOKIE['email'].'" required="">');
                    } else {
                        echo('<input type="email" class="form-control" id="email" 
                           placeholder="Insira seu email" name="email" required="">');
                    }
                    ?>     
                </div>
                <div class="form-group">
                    <label for="descricao">Senha:</label>
                    <input type="password" class="form-control" id="senha"  placeholder="Senha" name="senha" required=""> 
                </div> 
                <?php
                    //botao para lembrar
                    if (isset($_COOKIE['email'])) {
                        echo ('<input type="checkbox" class="form-check-input" id="lembrar" 
                           name="lembrar" checked value="1">');
                    } else {
                        echo ('<input type="checkbox" class="form-check-input" id="lembrar" 
                           name="lembrar" value="1">');
                    }
                    ?>
                    <label for="lembrar" style="color: black" class="form-check-label">Lembre de mim</label>
                  
              <br>
                <div class="d-grid">
                   <button type="submit"class="btn btn-default">Entrar</button>
                 </div></form>
                         <p>Não possui conta? <a href="cadastrar.php">Cadastrar-se</a></p></div></div></div>
                 <?php
                @$cod = $_REQUEST['cod'];
                if(isset($cod)){
                      
                        if ($cod == '171') {
                            echo ('<br><div class="alert alert-danger">');
                            echo ('Verifique usuário ou senha.');
                            echo ('</div>');
                        } else if ($cod == '172') {
                            echo ('<br><div class="alert alert-warning">');
                            echo ('Sua sessão expirou. Realize o login novamente.');
                            echo ('</div>');
                        }
                    }
                    ?>

        <?php
        // put your code here
        ?>
    </body>
</html>
