<?php

require_once 'ConexaoMysql.php';

class itensModel {

    protected $id;
    protected $nome;
    protected $quantidade;
    protected $precoVenda;
    
    
    public function getId() {
        return $this->id;
    }

    public function getNome() {
        return $this->nome;
    }

    public function getQuantidade() {
        return $this->quantidade;
    }

    public function getPrecoVenda() {
        return $this->precoVenda;
    }
    
    public function setId($id): void {
        $this->id = $id;
    }

    public function setNome($nome): void {
        $this->nome = $nome;
    }

    public function setQuantidade($quantidade): void {
        $this->quantidade = $quantidade;
    }

    public function setPrecoVenda($precoVenda): void {
        $this->precoVenda = $precoVenda;
    }
        public function __construct() {
     
    }

    

//Métodos especialistas
public function loadAll(){

    //Criar um objeto de conexão
    $db = new ConexaoMysql();

    //Abrir conexão com banco de dados
    $db->Conectar();

    //Criar consulta
    $sql = 'SELECT * FROM itens';
    //Executar método de consulta
    $resultList = $db->Consultar($sql);

    //Desconectar do banco
    $db->Desconectar();

    return $resultList;
}

/*
 * Carrega a itens pelo identificador único
 */

public function loadById($id) {

    //Criar um objeto de conexão
    $db = new ConexaoMysql();

    //Abrir conexão com banco de dados
    $db->Conectar();

    //Criar consulta
    $sql = 'SELECT * FROM itens where id =' . $id;
    //Executar método de consulta
    $resultList = $db->Consultar($sql);

    //Verifica se retornou um registro da base de dados
    if ($db->total == 1) {
        //Se retornou preenche as propriedades de itens
        foreach ($resultList as $value) {
            $this->id = $value['id'];
            $this->nome = $value['nome'];
            $this->quantidade= $value['quantidade'];
            $this->precoVenda = $value['precoVenda']; 
      
        }
    }


    //Desconectar do banco
    $db->Desconectar();

    return $resultList;
}}
