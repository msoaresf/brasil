<?php

require_once 'ConexaoMysql.php';


class carrinhoModel {
    protected $id;
    protected $usuarioCarrinho;
    protected $itensCarrinho;
    
}