<?php
require_once 'ConexaoMysql.php';
class usuarioModel {
    protected $id;
    protected $nome;
    protected $email;
    protected $senha;
    
    public function __construct() {
        
    }
    public function getId() {
        return $this->id;
    }
    public function getNome(){
        return$this->nome;
    }

    public function getEmail() {
        return $this->email;
    }

    public function getSenha() {
        return $this->senha;
    }

    public function setId($id): void {
        $this->id = $id;
    }
    
    public function setNome($nome): void {
        $this->nome = $nome;
    }

    public function setEmail($email): void {
        $this->email = $email;
    }

    public function setSenha($senha): void {
        $this->senha = $senha;
    }
    
    
    
public function loadAll() {

        //Criar um objeto de conexão
        $db = new ConexaoMysql();

        //Abrir conexão com banco de dados
        $db->Conectar();

        //Criar consulta
        $sql = 'SELECT * FROM usuario';
        //Executar método de consulta
        $resultList = $db->Consultar($sql);

        //Desconectar do banco
        $db->Desconectar();

        return $resultList;
    }

    /*
     * Carrega a usuario pelo identificador único
     */


function cadastrar($email, $senha) {
   
   $db = new ConexaoMysql();
    $db->Conectar();

//insere
    $sql = "INSERT INTO usuario (email, senha) VALUES ('$email', '$senha')";
    
  
    $db->Executar($sql);

      
        $db->Desconectar();

        return $db->total;

  
  
     $resultList = $db->Consultar($sql);

    // Fechar a conexão com o banco de dados
      $db->Desconectar();

    return $resultList;
}



   
        public function login($email, $senha) {

        //Criar um objeto de conexão
        $db = new ConexaoMysql();

        //Abrir conexão com banco de dados
        $db->Conectar();

        //Criar consulta
        $sql = 'SELECT * FROM usuario'. ' where email ="'.$email.'" ' . 'AND senha="'.$senha.'"';
        //Executar método de consulta
        $resultList = $db->Consultar($sql);

        //Verifica se retornou um registro da base de dados
        if ($db->total == 1) {
            //Se retornou preenche as propriedades de proprietarios
            foreach ($resultList as $value) {
                $this->id = $value['id'];
                $this->email = $value['email'];
                $this->senha = $value['senha'];
            }
        }


        //Desconectar do banco
        $db->Desconectar();
        
        return $db->total;
    }


     
    
    
    
}