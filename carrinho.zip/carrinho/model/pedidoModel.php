<?php

require_once 'ConexaoMysql.php';


class pedidoModel {
    protected $id;
    protected $dataHoraCompra;
    protected $carrinhoCompra;
    
    public function getId() {
        return $this->id;
    }

    public function getDataHoraCompra() {
        return $this->dataHoraCompra;
    }

    public function getCarrinhoCompra() {
        return $this->carrinhoCompra;
    }

    public function setId($id): void {
        $this->id = $id;
    }

    public function setDataHoraCompra($dataHoraCompra): void {
        $this->dataHoraCompra = $dataHoraCompra;
    }

    public function setCarrinhoCompra($carrinhoCompra): void {
        $this->carrinhoCompra = $carrinhoCompra;
    }

    public function __construct() {
        
    }

    
}