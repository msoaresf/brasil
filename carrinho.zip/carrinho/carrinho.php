<!DOCTYPE html>
<?php
require_once './shared/header.php';
require_once './model/ConexaoMysql.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>carrinho</title>
        <style>

        </style>
    </head>
    <body>
   
    <div class="row">
    <div class="col-sm-3"></div>
    <div class="col-sm-6">

        <?php
require_once './model/itensModel.php';
//Produtos

session_start();
echo '<h2>Carrinho</h2>';

echo '<br>';
$totalItensCarrinho = count($_SESSION['carrinho']);
$itensList = $_SESSION['carrinho'];
foreach ($itensList as $key => $value) {
    // Produto atual
    $itensAtual = $value;
    $totalItensAtual = 0;
    for ($i = 0; $i < $totalItensCarrinho; $i++) {
        if ($itensAtual == $itensList[$i]) {
            $totalItensAtual++;
        }
    }

    $item = loadById($itensAtual);
    foreach ($item as $itensAtual) {
echo '<table class="table">';
echo '<thead>';
echo '<tr>';
echo '<th>PRODUTO<th>';
echo '<th>VALOR<th>';
echo '</thead>';
echo '<tbody>';
echo '<tr>';
echo '<td>';
echo '<img src="'.$itensAtual['img'].'"width="24%">';
echo '</td>';
echo '<td>';
echo '<h4>'.$itensAtual['nome'].'</h4>';
echo '<input type="number" value='.$totalItensAtual.'>';
echo '</td>';
echo '<td>';
echo '<br><br>';
echo 'R$' .$itensAtual['precoVenda'].'';
echo '</td>';
echo '</tr>';
echo '</tbody>';
echo '</div>';

$valor= $itensAtual['precoVenda']*$totalItensAtual;
echo'<h4>Valor total:'.$valor.'</h4>';

}}

for($i=0 ;$i < $totalItensCarrinho; $i++){
    $valori= $valor;
    echo'<h4>Valor total:'.$valori.'</h4>';
}

?>

<form method="post" action="controller/limparController.php">
    <button type="submit" name="limpar_carrinho" value="Limpar Carrinho">Limpar Carrinho</button>
</form>


</div>
        
</div>

<?php 
      

      function loadById($itemId) {
     
         //Criar um objeto de conexão
         $db = new ConexaoMysql();
     
         //Abrir conexão com banco de dados
         $db->Conectar();
     
         //Criar consulta
         $sql = 'SELECT * FROM itens where id =' . $itemId;
         //Executar método de consulta
         $resultList = $db->Consultar($sql);
     
         $db->Desconectar();
     
         return $resultList;
     }
     
           ?>
    </body>
</html>
