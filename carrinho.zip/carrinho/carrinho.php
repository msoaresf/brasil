<!DOCTYPE html>
<?php
//require_once '';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>carrinho</title>
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <style>
             ul{
  position: fixed;
  width: 90%;
  z-index:2;
  padding: 1%;
}
  
        </style>
    
    </head>
    <body>
        <div class="row"></div><br><br><br>
   
           <ul>
               <li><a href="index.php">PRODUTOS</a></li>
          <li style="float:right"><a href="carrinho.php">Carrinho</a></li>
        </ul>
      
        <div class="row">
            <div class="col-sm-2"></div>
            <div class="col-sm-8">
                <h3>CARRINHO:</h3> 
                <?php
// Exibir o carrinho
echo "<h2>Carrinho:</h2>";
$total = 0;
if(isset($_SESSION["carrinho"])) {
    foreach($_SESSION["carrinho"] as $item) {
        $subtotal = $item["valor"] * $item["quantidade"];
        echo "Nome: " . $item["nome"] . " - Valor unitário: " . $item["valor"] . " - Quantidade: " . $item["quantidade"] . " - Subtotal: " . $subtotal . "<br>";
        $total += $subtotal;
    }
}

echo "<br>Total: " . $total;
?>

                
            </div>
            <div class="col-sm-2"></div>
        </div>
        
   
        
    
    </body>
</html>
