create database carrinho;
use carrinho;


create table usuario(
id int auto_increment not null,
nome varchar(40),
email varchar(50),
senha varchar(40),
primary key (id));

create table itens(
id int auto_increment not null,
nome varchar(40),
img varchar(50),
quantidade int,
primary key (id));

create table carrinho(
id int auto_increment not null,
usuarioCarrinho int,
itensCarrinho int, 
foreign key (itensCarrinho) references itens(id),
foreign key (usuarioCarrinho) references usuario(id),
primary key (id));

create table pedido(
id int auto_increment not null,
dataHoraCompra datetime, 
carrinhoCompra int,
foreign key (carrinhoCompra) references carrinho(id),
primary key (id));

INSERT INTO `carrinho`.`itens` (`nome`, `quantidade`) VALUES ('Banana', '54');
INSERT INTO `carrinho`.`itens` (`nome`, `quantidade`) VALUES ('Maca', '76');
INSERT INTO `carrinho`.`itens` (`nome`, `quantidade`) VALUES ('Pera', '43');
INSERT INTO `carrinho`.`itens` (`nome`, `quantidade`) VALUES ('Melancia', '65');
INSERT INTO `carrinho`.`itens` (`nome`, `quantidade`) VALUES ('Uva', '78');
INSERT INTO `carrinho`.`itens` (`nome`, `quantidade`) VALUES ('Pitaia', '54');

ALTER TABLE `carrinho`.`itens` 
ADD COLUMN `precoVenda` FLOAT NULL AFTER `quantidade`;
UPDATE `carrinho`.`itens` SET `precoVenda` = '4.00' WHERE (`id` = '1');
UPDATE `carrinho`.`itens` SET `precoVenda` = '6.77' WHERE (`id` = '2');
UPDATE `carrinho`.`itens` SET `precoVenda` = '5.43' WHERE (`id` = '3');
UPDATE `carrinho`.`itens` SET `precoVenda` = '11.08' WHERE (`id` = '4');
UPDATE `carrinho`.`itens` SET `precoVenda` = '4.50' WHERE (`id` = '5');
UPDATE `carrinho`.`itens` SET `precoVenda` = '12.86' WHERE (`id` = '6');

UPDATE `carrinho`.`itens` SET `img` = 'img/banana.jpg' WHERE (`id` = '1');
UPDATE `carrinho`.`itens` SET `img` = 'img/maca.jpg' WHERE (`id` = '2');
UPDATE `carrinho`.`itens` SET `img` = 'img/melancia.webp' WHERE (`id` = '4');
UPDATE `carrinho`.`itens` SET `img` = 'img/pera.webp' WHERE (`id` = '3');
UPDATE `carrinho`.`itens` SET `img` = 'img/pitaia.webp' WHERE (`id` = '6');
UPDATE `carrinho`.`itens` SET `img` = 'img/uva.png' WHERE (`id` = '5');
