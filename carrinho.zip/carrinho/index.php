<!DOCTYPE html>
<?php
require_once './shared/header.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>carrinho</title>
        <style>
.item{
    padding-left:2%;
    border:groove;
    border-radius: 2%;
    padding: 40px;
    text-align: center;
    
}
        </style>
    </head>
    <body>
        <br><br><br>
        <?php
            require_once './controller/itensController.php';
            $itensList = loadAll();
            //Exibir resultado
            foreach ($itensList as $itens) {
                echo '<div class="col-sm-3">';
                echo '<div class="item">';
                echo '<img src="';
                echo $itens['img'];
                echo '" width="50%">';
                echo '</td>';
                echo '<h3>';
                echo $itens['nome'];
                echo '</h3>';
                    echo '<h4>';
                    echo 'R$';
                        echo $itens['precoVenda'];
                    echo '</h4>';
                    echo '<p>';
                        echo 'Quantidade: ';
                        echo $itens['quantidade'];
                    echo '</p>';
                    echo '<button class="btn btn-button"><a href="./controller/carrinhoController.php?itensId='.$itens['id'].'"> Adicionar ao carrinho</a></button>';
                    echo '</div>';
            echo '<br>';
            echo '</div>';


            }
            echo '<br>';
        ?>
    </body>
</html>
