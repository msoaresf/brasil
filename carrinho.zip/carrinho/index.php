<!DOCTYPE html>
<?php
//require_once '';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>carrinho</title>
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <style>
              .header{
  position: fixed;
  width: 100%;
  height: 20%;
  z-index:2;
}
  
        </style>
    
    </head>
    <body>
      
        <header>
           <ul>
               <li><a href="index.php">PRODUTOS</a></li>
          <li style="float:right"><a href="carrinho.php">Carrinho</a></li>
        </ul>
        </header>
        
          <div class="row"></div><br><br><br>
        <div class="col-md-2"></div>
        <?php
            require_once './controller/itensController.php';
            $itensList = loadAll();
            //Exibir resultado
            foreach ($itensList as $itens) {
                echo '<div class="col-md-3">';
                echo '<img src="';
                echo $itens['img'];
                echo '" width="30%" height="20%">';
                echo '</td>';
                echo '<h3>';
                echo $itens['nome'];
                echo '</h3>';
                    echo '<h4>';
                    echo 'R$';
                        echo $itens['precoVenda'];
                    echo '</h4>';
                    echo '<p>';
                        echo $itens['quantidade'];
                    echo '</p>';
                    echo '<button class="btn btn-button">Adicionar ao carrinho</button>';
                    echo '</div>';
            }
        ?>
        
    
    </body>
</html>
